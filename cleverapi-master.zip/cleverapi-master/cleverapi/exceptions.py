class LongPollException(Exception):
    pass

class ApiResponseError(Exception):
    pass